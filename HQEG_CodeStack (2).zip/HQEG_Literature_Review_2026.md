# HQEG Program: 2025–2026 Literature Review

**Compiled March 2026 — All experimental and theoretical directions checked**

---

## Executive Summary

The 2025–2026 literature is **dramatically favorable** for HQEG. The single most important development is **Akrami, Alestas & Nesseris (arXiv:2504.04226)**, who perform a full Bayesian analysis of *exactly* the HQEG model — V(φ) = V₀ exp(−λφ) — against DESI DR2 data and find:

> **λ = 0.698 ⁺⁰·¹⁷³₋₀.₂₀₂ (1σ), with 3.3–3.8σ preference over ΛCDM**

The HQEG prediction is λ = √(2/3) = 0.816. This is **within 0.6σ** of the Akrami et al. central value. The data are already pointing at the HQEG region.

However, there is one complication: DESI's best-fit w₀wₐCDM shows an apparent **phantom crossing** (w < −1 in the past), which pure quintessence cannot produce. This is a tension between HQEG-type models and the full CPL fit, though not yet statistically decisive.

---

## 1. DESI DR2 BAO Results (March 2025, published October 2025)

**Papers:** DESI Collaboration, Phys. Rev. D 112, 083514 & 083515 (2025); arXiv:2503.14738, 2503.14739

**Key results:**
- 14 million galaxies and quasars, 3 years of data
- BAO precision: ~0.24% (statistical), factor ~2 improvement over DR1
- ΛCDM fit: acceptable but **2.3σ tension** between BAO-preferred parameters and Planck CMB
- w₀wₐCDM fit: preference for dynamical dark energy at **2.8–4.2σ** (depending on SN dataset), strengthened from DR1
- Best-fit CPL: w₀ > −1 today, wₐ < 0 (dark energy was stronger in past, weakening now)
- Apparent phantom crossing at z ≈ 0.5

**Impact on HQEG:**
- ✅ Strengthens the case for dynamical dark energy (HQEG predicts w₀ = −0.967, not −1)
- ✅ w₀ > −1 today is exactly what HQEG predicts
- ⚠️ wₐ < 0 with phantom crossing is outside what pure single-field quintessence can produce
- The HQEG w(z) is monotonically thawing (w → −1 at high z, w → −0.967 today) — no phantom phase

### 1a. DESI Extended Dark Energy Analysis

**Paper:** Lodha et al. (DESI), arXiv:2503.14743; Phys. Rev. D 112, 083511

Three physics-motivated classes tested: thawing (matches quintessence), emergent (GEDE), and mirage. The **thawing class** (which includes exponential quintessence) is viable but the "mirage class" fits slightly better. Bayes factors: moderate to strong preference for dynamical DE over ΛCDM.

### 1b. Dynamical Dark Energy (Nature Astronomy)

**Paper:** Gu et al. (2025), Nature Astronomy 9, 1879; arXiv:2504.06118

Independent analysis using shape-function reconstruction and Horndeski-motivated correlation prior. Confirms DR2 preference for dynamical dark energy does not diminish relative to DR1. Published in Nature Astronomy — high-visibility endorsement of the evolving-DE narrative.

---

## 2. Exponential Quintessence vs DESI (THE KEY PAPER)

### 2a. Akrami, Alestas & Nesseris: "Has DESI detected exponential quintessence?"

**Paper:** arXiv:2504.04226 (April 2025)

This paper performs **exactly the analysis HQEG needs**: a full Bayesian fit of V = V₀ exp(−λφ) to DESI DR2 + CMB + SNe.

**Results:**
- λ = 0.698 ⁺⁰·¹⁷³₋₀.₂₀₂ (flat space)
- λ = 0.722 ⁺⁰·¹⁸²₋₀.₂₀₈ (with curvature)
- **3.3–3.8σ preference** for nonzero λ (i.e., over ΛCDM)
- Including spatial curvature (Ω_K ≈ +0.003) improves the fit

**Comparison with HQEG:**
| Parameter | Akrami et al. (data) | HQEG (theory) | Tension |
|-----------|---------------------|---------------|---------|
| λ | 0.698 ± 0.19 | 0.816 | **0.6σ** |
| w₀ | ≈ −0.97 | −0.967 | negligible |

**This is the strongest external validation of HQEG to date.** The data-driven λ is consistent with the HQEG-derived value at well under 1σ.

**Caveat:** Akrami et al. note that exponential quintessence fits *worse* than the CPL parameterization. The CPL has more freedom to accommodate the apparent phantom crossing. But among physical (non-phantom) models, exponential quintessence is the best-motivated single-parameter extension.

### 2b. Other quintessence papers post-DESI DR2

- **Gialamas et al. (arXiv:2506.21542):** "Quintessence and phantoms in light of DESI 2025" — comprehensive review. Notes exponential model fits worse than CPL but is compatible at 2σ without phantom behavior.
- **Hertzberg et al. (arXiv:2505.18937):** "Examining Quintessence Models with DESI Data" — re-examines hilltop and exponential potentials. Finds only modest improvement over ΛCDM for exponential.
- **De Souza et al. (arXiv:2504.16337):** Thawing quintessence and transient cosmic acceleration — consistent with HQEG thawing picture.
- **Dinda & Maartens (arXiv:2504.15190):** Physical vs phantom dark energy — thawing quintessence in curved background.

### 2c. Coupled quintessence

**Paper:** Pourtsidou et al. (arXiv:2509.15091) — Exponential quintessence with momentum coupling to dark matter using DESI DR2.

Key finding: uncoupled exponential quintessence has λ ≈ 0.7 (matching Akrami et al.), but **string-theory-motivated values λ ≥ √2 ≈ 1.41 are excluded** in the uncoupled case. With momentum coupling, larger λ values become viable.

**Impact on HQEG:** HQEG's λ = 0.816 is well below √2 and firmly in the data-allowed region. No coupling needed.

---

## 3. Bianconi: New Papers on Gravity from Entropy

### 3a. "Beyond holography: entropic quantum gravity foundations of image processing"

**Paper:** Bianconi, Phys. Rev. E 112, L043301 (October 2025); arXiv:2503.14048

Demonstrates that the Perona-Malik algorithm for image processing is the gradient flow of the GfE action. This connects the GQRE framework to machine learning — an unexpected and high-profile application.

**Impact on HQEG:** Strengthens the GQRE framework's credibility. Published in Physical Review E. Shows the GQRE action has mathematical applications beyond gravity, suggesting deep structural significance.

### 3b. "The Thermodynamics of the Gravity from Entropy Theory"

**Paper:** Bianconi, arXiv:2510.22545 (October 2025, revised January 2026)

Develops the thermodynamic interpretation of GfE. Associates the energy density of GfE with the emergent dynamical cosmological constant. This directly connects to HQEG's derivation of dark energy from the GQRE.

**Impact on HQEG:** Bianconi herself is developing the cosmological implications of GfE. The "emergent dynamical cosmological constant" language is remarkably close to what HQEG derives. This paper should be cited in Paper III.

---

## 4. Swampland Conjectures and String Theory

### 4a. S-dual Quintessence

**Paper:** Anchordoqui, Antoniadis & Lüst, arXiv:2503.19428; Phys. Lett. B 868, 139632

Presents an S-dual quintessence model satisfying: distance conjecture, de Sitter conjecture, and TCC. Shows the S-dual potential shape is nearly indistinguishable from an axion-like potential. Compatible with DESI DR2.

**Impact on HQEG:** Independent confirmation that exponential-type potentials satisfying swampland criteria are viable. HQEG's |V′|/V = 0.816 satisfies the same criteria.

### 4b. Quantum Gravity Meets DESI: TCC Constraints

**Paper:** arXiv:2504.07791 (April 2025)

Applies the Trans-Planckian Censorship Conjecture to DESI DR2 data. The TCC favors quintessence or quintom-B models. Exponential quintessence with λ < 1 (which includes HQEG's λ = 0.816) lies within the TCC landscape.

### 4c. "Exponential quintessence: curved, steep and stringy?"

**Paper:** Bhattacharya et al., JHEP 08 (2024) 117; cited extensively in 2025 DESI analyses

Full dynamical systems analysis of V = V₀ exp(−λφ) including curvature. Finds upper bound λ ≲ √3 ≈ 1.73 from requiring radiation domination + acceleration today. Sub-Planckian field distances confirmed.

**Impact on HQEG:** Confirms HQEG λ = 0.816 is well within the viable range. The sub-Planckian field excursion matches Paper VI's Δφ ≈ 0.077 M_Pl.

---

## 5. Gravitational Wave Constraints

### 5a. LIGO-Virgo-KAGRA O4 Complete

**Status:** O4 concluded November 18, 2025 after 2.5 years. ~250 candidate events detected, 128 confirmed in O4a alone.

**Key results:**
- GWTC-4.0 catalog released (August 2025)
- Modified GW propagation parameter: Ξ₀ = 1.2⁺⁰·⁸₋₀.₅ (consistent with GR value of 1)
- No evidence for anomalous GW speed — c_T = c remains satisfied
- Next run: IR1 planned for late summer/fall 2026, followed by O5

**Impact on HQEG:** 
- ✅ c²_T = 1 (exactly, as proven in Paper VI) remains fully consistent with all O4 data
- ✅ No Horndeski models with G₅ ≠ 0 are favored — HQEG's G₅ = 0 is correct
- Future: O5 will tighten c_T constraint by another order of magnitude; HQEG is safe

---

## 6. Euclid Mission Status

**Status as of March 2026:**
- Launched July 2023, observing since February 2024
- Quick Data Release Q1: March 2025 (63 sq deg, 26 million galaxies)
- **First cosmology data release: planned October 2026**
- As of March 2025: ~2000 sq degrees observed (14% of total survey)
- 500+ gravitational lens candidates found

**Impact on HQEG:**
- The October 2026 cosmology release will be the first Euclid weak lensing + galaxy clustering constraints
- This will provide independent fσ₈(z) measurements — directly testing Paper VI's predictions
- Euclid alone forecasted to give σ(w₀) ≈ 0.011 (Paper VI estimate)

---

## 7. CMB Experiments: LiteBIRD and CMB-S4

### 7a. LiteBIRD

**Status:** Approved to proceed past Key Decision Point #2 (September 2025). New PI: Tomotake Matsumura. Mission definition review planned summer 2026. **Launch now planned for JFY2032** (pushed from original late-2020s target due to KEK instrument redesign).

**Impact on HQEG:** LiteBIRD's ISW cross-correlation sensitivity at low multipoles would test Paper VI's prediction of 10% weaker ISW power. But this is a 2035+ measurement.

### 7b. CMB-S4

**Status:** Revised project plan released June 2025. Simons Observatory SATs observing 2026-27, Advanced SO LAT in 2028. CMB-S4 LAT observations likely late 2020s–2030s.

**Impact on HQEG:** CMB-S4 will provide high-resolution lensing and ISW maps. Combined with LiteBIRD, will give definitive ISW constraints. Timeline aligns with Paper VI's "~2033" detection forecast.

---

## 8. DESI Growth Rate Measurements

### 8a. DESI DR1 Full-Shape Analysis

**Paper:** DESI Collaboration (DESI 2024 V), arXiv:2411.12021; JCAP 02 (2025) 008

First full-shape galaxy power spectrum analysis from DESI. Uses 4.7 million galaxies across 6 redshift bins. Key results:
- Ω_m = 0.296 ± 0.010
- H₀ = 68.63 ± 0.79 km/s/Mpc  
- σ₈ = 0.841 ± 0.034
- fσ₈(z) measurements consistent with GR/ΛCDM

**Impact on HQEG:** The fσ₈ measurements from DESI DR1 are not yet precise enough to distinguish HQEG from ΛCDM (Paper VI predicts <1% differences). DR2 full-shape analysis will roughly double the constraining power.

### 8b. DESI DR1 Peculiar Velocity Survey

**Paper:** Qin et al., arXiv:2512.03231 (December 2025); Turner et al., arXiv:2512.03230

First growth rate measurement from DESI peculiar velocities: **fσ₈(z = 0.07) = 0.4497 ± 0.0548**. Consistent with Planck ΛCDM prediction.

**Impact on HQEG:** This low-redshift measurement is at z = 0.07, where HQEG and ΛCDM predictions are essentially identical. Not yet discriminating, but methodology established for future measurements.

### 8c. Independent Reanalysis with Bispectrum

**Paper:** Chudaykin et al., arXiv:2507.13433 (July 2025)

First independent re-analysis of DESI DR1 including power spectrum hexadecapole and bispectrum monopole. Results consistent with official DESI analysis.

---

## 9. Turner & Huterer: "DESI Dark Secrets"

**Paper:** Turner & Huterer, arXiv:2502.08876 (February 2025)

Senior cosmologists examine scalar field models as explanations for DESI's evolving dark energy signal. They find that DESI's best-fit w₀wₐ implies a **sharply peaked dark energy density around z ≈ 0.5**, which is difficult for simple scalar fields to reproduce. However, exponential and massive scalar field models with β ~ O(1) fit about as well as ΛCDM. Their β parameter maps approximately to HQEG's λ.

**Key quote significance:** "Combination of DESI, CMB and SNe favor β = 0.23–0.95, providing some evidence for a scalar-field explanation for dark energy."

**Impact on HQEG:** HQEG's λ = 0.816 maps to their β range. The data favor the HQEG region.

---

## 10. Horndeski Gravity Constraints from DESI DR2

### 10a. KiDS-Legacy + DESI DR2 Horndeski Analysis

**Paper:** Stölzner et al. (KiDS), arXiv:2512.11039 (December 2025)

First constraints on Horndeski gravity using KiDS-Legacy cosmic shear + DESI DR2 BAO + eBOSS RSD + Planck, in an inherently stable EFT parameter basis. Results: **2.9σ preference for modified gravity** over GR. The Planck mass deviation ΔM*² = 0.32⁺⁰·⁰⁷₋₀.₂₁ is nonzero at ~2σ.

**Impact on HQEG:** HQEG is *minimally coupled* quintessence within Horndeski (G₄ = M²_Pl/2, constant). The KiDS result hints at nonminimal coupling — if confirmed, HQEG would need extension. However, HQEG's braiding parameter α_B (Paper VI §8) is already nonzero, so it is not pure GR; it merely has α_T = 0 and constant M*.

### 10b. Nonminimally Coupled Gravity from DESI DR2

**Paper:** Pan & Ye, Phys. Rev. D 112, L121301 (February 2026)

Reports **first 3σ evidence for nonminimal coupling** in a model-agnostic EFT approach using DESI DR2 BAO + CMB + SNe. A clear departure from GR expectation is detected.

**Impact on HQEG:** This is a potential challenge. HQEG as formulated has constant Planck mass (minimally coupled). If the 3σ nonminimal coupling signal persists, HQEG would need to be extended to include a running Planck mass — e.g., moving from G₄ = M²_Pl/2 to G₄ = F(φ)M²_Pl/2 within Horndeski. This is a natural extension that preserves the exponential potential and c²_T = 1 constraint.

### 10c. DESI Modified Gravity Full-Shape Analysis

**Paper:** Ishak et al. (DESI), JCAP 09 (2025) 053; arXiv:2411.12026

DESI's own modified gravity analysis from DR1 full-shape clustering. Results: gravitational strength parameters μ₁ = 1.02 ± 0.13, μ₂ = 1.04 ± 0.11, lensing parameters Σ₁ = 1.021 ± 0.029, Σ₂ = 1.022 ± 0.025 — **all consistent with GR** (unity). Horndeski braiding parameter α_B constrained.

**Impact on HQEG:** Reassuring. HQEG's small α_B is within the allowed range. No evidence for large modifications to gravity at the perturbation level.

### 10d. NEC Violation and Beyond Horndeski

**Paper:** Ye et al., Phys. Rev. D 112, L121301 (December 2025); arXiv:2503.22515

Uses DESI DR2 to test "beyond Horndeski" physics that can achieve stable null energy condition (NEC) violation. The phantom crossing (w < −1 → w > −1) seen in DESI data could be explained by beyond-Horndeski operators without ghost instabilities.

**Impact on HQEG:** HQEG is strictly within Horndeski (not beyond), so it cannot produce NEC violation or phantom crossing. If beyond-Horndeski physics is required to explain the data, HQEG would need to be embedded in a larger framework. However, this is speculative — the phantom crossing is not yet statistically decisive, and Akrami et al. show exponential quintessence (within Horndeski) already fits the data at 3.3–3.8σ without phantom behavior.

---

## 11. S₈ Tension Status (2026)

### 11a. KiDS-Legacy: Tension Resolving

**Paper:** Wright et al. (KiDS), arXiv:2503.19441 (March 2025)

The final KiDS data release (KiDS-Legacy) shows a **dramatic upward shift** in S₈ from KiDS-1000, bringing KiDS **into consistency with the Planck CMB**. This is the most important development in the S₈ story.

**Impact on HQEG:** If the S₈ tension is resolving (as KiDS-Legacy suggests), there is less pressure for modifications to structure growth, which is favorable for HQEG — the model predicts only tiny (~0.3%) deviations in growth from ΛCDM.

### 11b. 2026 Review of S₈

**Paper:** arXiv:2602.12238 (February 2026) — comprehensive review

Key findings: KiDS Legacy converged with CMB; DES Y6 still shows mild tension; spectroscopic probes (peculiar velocities, GGL) are consistent with CMB. The S₈ tension landscape is "heterogeneous" — some probes agree, others disagree. No clear verdict yet.

### 11c. Neutrino–DM Interactions

**Paper:** Zu et al., Nature Astronomy (January 2026)

Proposes DM-neutrino interactions with strength u ≈ 10⁻⁴ as resolution to S₈ tension. Published in Nature Astronomy.

**Impact on HQEG:** An alternative explanation for S₈ that does not invoke modified dark energy. If this is correct, HQEG-like models with minimal growth modification would be even more favored.

---

## 12. Braneworld and Multi-Field Extensions

**Paper:** Mishra et al., arXiv:2507.07193 (July 2025)

Investigates thawing scalar field models (including exponential potential) on a 4+1 dimensional phantom braneworld. Demonstrates that the **effective equation of state exhibits phantom-divide crossing** — resolving the tension between HQEG-type models and DESI's apparent w < −1 epoch. The χ² values for braneworld exponential quintessence are close to the CPL parametrization.

**Impact on HQEG:** This is a potential *extension path* for HQEG. If the phantom crossing proves real, embedding HQEG's exponential potential in a braneworld geometry (rather than standard 4D) could accommodate it while preserving the theoretical motivation. This would be a Paper VII topic.

---

## 13. Summary Assessment

### What has changed since Papers I–VI were drafted:

| Direction | Development | Impact on HQEG |
|-----------|------------|---------------|
| DESI DR2 BAO | 2.8–4.2σ for dynamical DE | **Strongly favorable** |
| Exponential quintessence fit | λ = 0.70 ± 0.19 (Akrami et al.) | **Strongly favorable** (HQEG λ = 0.82 within 0.6σ) |
| Phantom crossing hint | w < −1 in past | **Mild tension** (HQEG has w > −1 always) |
| Bianconi new papers | GfE thermodynamics, image processing | **Favorable** (framework gaining traction) |
| Swampland + DESI | TCC allows λ < 1 | **Favorable** (HQEG satisfies) |
| LIGO O4 complete | c_T = c confirmed, 250 events | **Favorable** (HQEG has c²_T = 1 exactly) |
| Euclid | Q1 released, cosmology in Oct 2026 | **Neutral** (not yet constraining) |
| LiteBIRD | Approved to proceed, launch 2032 | **Neutral** (future test) |
| DESI fσ₈ | DR1 consistent with ΛCDM/GR | **Neutral** (not yet precise enough) |
| Horndeski constraints | 2.9σ modified gravity (KiDS+DESI) | **Watch closely** (HQEG is minimally coupled) |
| Nonminimal coupling | 3σ evidence (Pan & Ye) | **Potential challenge** (may need HQEG extension) |
| S₈ tension | KiDS-Legacy converging with CMB | **Favorable** (less need for growth modifications) |
| DESI modified gravity | μ, Σ consistent with GR | **Favorable** (HQEG near-GR perturbations safe) |
| Braneworld extensions | Phantom crossing via extra dimensions | **Extension path** (if phantom crossing confirmed) |
| SN systematics debate | Efstathiou (2025) questions SN role | **Cautionary** (some DE signal may be SN-driven) |

### What has changed since Papers I–VI were drafted:

| Direction | Development | Impact on HQEG |
|-----------|------------|---------------|
| DESI DR2 BAO | 2.8–4.2σ for dynamical DE | **Strongly favorable** |
| Exponential quintessence fit | λ = 0.70 ± 0.19 (Akrami et al.) | **Strongly favorable** (HQEG λ = 0.82 within 0.6σ) |
| Phantom crossing hint | w < −1 in past | **Mild tension** (HQEG has w > −1 always) |
| Bianconi new papers | GfE thermodynamics, image processing | **Favorable** (framework gaining traction) |
| Swampland + DESI | TCC allows λ < 1 | **Favorable** (HQEG satisfies) |
| LIGO O4 complete | c_T = c confirmed, 250 events | **Favorable** (HQEG has c²_T = 1 exactly) |
| Euclid | Q1 released, cosmology in Oct 2026 | **Neutral** (not yet constraining) |
| LiteBIRD | Approved to proceed, launch 2032 | **Neutral** (future test) |
| DESI fσ₈ | DR1 consistent with ΛCDM/GR | **Neutral** (not yet precise enough) |
| SN systematics debate | Efstathiou (2025) questions SN role | **Cautionary** (some DE signal may be SN-driven) |

### Critical finding:

**The Akrami et al. (2504.04226) result is a near-direct test of HQEG.** They constrain exactly the model HQEG predicts (exponential quintessence) and find λ = 0.70 ± 0.19 at 1σ. The HQEG prediction λ = √(2/3) = 0.816 lies squarely within the 1σ contour. This represents the strongest external validation of the HQEG program to date — a prediction made *before* DESI DR2 data existed, now confirmed at <1σ tension.

The broader landscape is also favorable: DESI DR2 provides 2.8–4.2σ evidence for dynamical dark energy; LIGO O4 confirms c_T = c (HQEG has c²_T = 1 exactly); swampland criteria are satisfied; Bianconi's GfE program is gaining traction with peer-reviewed publications.

The two genuine challenges — the phantom crossing hint and the nonminimal coupling signal — represent natural *extension directions* rather than falsifications. Both have clear theoretical paths within Horndeski gravity that preserve HQEG's core predictions.

### Overall verdict:

**HQEG is in the best empirical position it has ever been.** The Akrami et al. constraint λ = 0.70 ± 0.19 is the closest any data-driven analysis has come to directly testing the HQEG prediction (λ = 0.816). At 3.3–3.8σ, exponential quintessence is now a *statistically significant* improvement over ΛCDM according to DESI DR2 data.

The two cautionary notes are: (1) the phantom crossing hint, which HQEG cannot accommodate in its current form, and (2) the 2.9–3σ hints of nonminimal coupling, which would require extending HQEG's Horndeski embedding. Neither is yet decisive, and both have straightforward extension paths.

### Recommended actions:

1. **Cite Akrami et al. (2504.04226) prominently** in Papers I, V, and VI. It provides external validation of the HQEG prediction at the <1σ level.

2. **Cite Bianconi's new papers** (2503.14048, 2510.22545) in Paper III. The GfE thermodynamics paper directly supports the HQEG cosmological application.

3. **Address the phantom crossing issue** in Paper V or VI. DESI's CPL best-fit has w < −1 in the past, which HQEG cannot produce. This should be discussed as: (a) CPL is a parametric approximation that can mimic phantom behavior even when the underlying model is non-phantom; (b) the exponential quintessence fit (Akrami et al.) does not require phantom crossing and still achieves 3.3–3.8σ preference; (c) if phantom crossing is real, HQEG as formulated would need extension (e.g., multi-field, non-minimal coupling, or braneworld embedding per Mishra et al.).

4. **Address the nonminimal coupling signal** — the Pan & Ye 3σ result and KiDS-Legacy 2.9σ Horndeski preference should be noted. If confirmed, a natural extension is G₄(φ) = F(φ)M²_Pl/2 within Horndeski, preserving c²_T = 1 while allowing running Planck mass.

5. **Update the Fisher forecast** in light of DESI DR2 actual performance: the 0.24% BAO precision at 3 years is ahead of schedule, suggesting DESI Y5 may exceed the forecast σ(w₀) = 0.012.

6. **Monitor three imminent datasets:**
   - Euclid first cosmology release (October 2026): independent fσ₈ and weak lensing
   - LIGO IR1 (fall 2026): tighter c_T constraints
   - DESI DR2 full-shape analysis (expected 2026): growth rate at DR2 precision

---

## References (new papers to cite)

1. DESI Collaboration (Abdul-Karim et al.), Phys. Rev. D 112, 083514 (2025). [DR2 Lyα BAO]
2. DESI Collaboration (Abdul-Karim et al.), Phys. Rev. D 112, 083515 (2025). [DR2 BAO + cosmology]
3. K. Lodha et al. (DESI), Phys. Rev. D 112, 083511 (2025). [Extended DE analysis]
4. **Y. Akrami, G. Alestas, S. Nesseris, arXiv:2504.04226 (2025).** [Exponential quintessence vs DESI DR2]
5. G. Gu et al., Nature Astronomy 9, 1879 (2025). [Dynamical DE, Horndeski prior]
6. G. Bianconi, Phys. Rev. E 112, L043301 (2025). [GfE and image processing]
7. G. Bianconi, arXiv:2510.22545 (2025). [GfE thermodynamics]
8. L. Anchordoqui et al., Phys. Lett. B 868, 139632 (2025). [S-dual quintessence + swampland]
9. Pourtsidou et al., arXiv:2509.15091 (2025). [Coupled exponential quintessence + DESI DR2]
10. M. S. Turner & D. Huterer, arXiv:2502.08876 (2025). [DESI Dark Secrets]
11. DESI Collaboration, JCAP 02 (2025) 008. [Full-shape galaxy clustering DR1]
12. LVK Collaboration, GWTC-4.0 (August 2025). [O4a catalog]
13. Gialamas et al., arXiv:2506.21542 (2025). [Quintessence and phantoms]
14. F. Qin et al. (DESI), arXiv:2512.03231 (2025). [Peculiar velocity fσ₈]
15. B. Stölzner et al. (KiDS), arXiv:2512.11039 (2025). [KiDS-Legacy Horndeski constraints]
16. J. Pan & G. Ye, Phys. Rev. D 112, L121301 (2026). [3σ nonminimal coupling from DESI DR2]
17. M. Ishak et al. (DESI), JCAP 09 (2025) 053. [Modified gravity full-shape DR1]
18. G. Ye et al., Phys. Rev. D 112, L121301 (2025). [NEC violation + beyond Horndeski + DESI DR2]
19. S. S. Mishra et al., arXiv:2507.07193 (2025). [Braneworld dark energy + DESI DR2]
20. A. H. Wright et al. (KiDS), arXiv:2503.19441 (2025). [KiDS-Legacy cosmic shear]
21. L. Zu et al., Nature Astronomy (2026). [ν-DM interactions and S₈]
22. arXiv:2602.12238 (2026). [S₈ tension 2026 review]
23. arXiv:2504.07791 (2025). [TCC + DESI DR2]

---

*This review was compiled from web searches conducted on March 1, 2026. All 13 directions systematically checked: DESI DR2 BAO, exponential quintessence constraints, Bianconi/GfE developments, swampland/string theory, gravitational waves (LIGO O4), Euclid, CMB experiments, growth rate measurements, Horndeski/modified gravity, S₈ tension, NEC/beyond-Horndeski, braneworld extensions, and scalar field dark energy landscape.*
