# HQEG in Context: Comparison with the Entropic Gravity Landscape

**February 14, 2026**

---

## I. The Landscape of Entropic/Emergent Gravity (2010–2026)

Six distinct research programs have attempted to derive gravity from entropy or information-theoretic principles over the past fifteen years. The HQEG program builds on and extends one of these (Bianconi's GfE). Here is how they compare.

---

### 1. Jacobson (1995, 2015): Thermodynamic Einstein Equation

**Core idea.** The Einstein equation is an equation of state. Apply δQ = TδS across local Rindler horizons at the Unruh temperature, with entropy proportional to horizon area. The Einstein equation follows as a thermodynamic identity.

**2015 refinement.** The "entanglement equilibrium" paper showed that if the vacuum entanglement entropy in small geodesic balls is maximized at fixed volume, the Einstein equation holds if and only if the stationarity condition is satisfied — for conformal fields.

**Strengths.** Conceptually profound. Shows that the Einstein equation has thermodynamic content. Requires minimal assumptions.

**Limitations.** Derives *only* the Einstein equation — no modifications, no cosmological constant, no specific dark energy model. Works cleanly only for conformal fields; non-conformal fields require an unproven conjecture. No falsifiable predictions beyond GR itself.

**Relation to HQEG.** Jacobson's result is the *low-coupling limit* of the GQRE. Bianconi's action reduces to the Einstein-Hilbert action when βR ≪ 1, recovering Jacobson's thermodynamic derivation as a limiting case. HQEG goes further by keeping the full non-linear structure, which produces dark energy, maximum curvature, and the cosmological bounce.

---

### 2. Verlinde (2011, 2016): Entropic Force and Emergent Dark Matter

**Core idea (2011).** Gravity is an entropic force: F = TΔS/Δx, using the holographic principle and the Unruh temperature. Newton's law and the Einstein equation emerge from the statistical tendency to maximize entropy.

**Core idea (2016).** In de Sitter space, a volume-law entropy contribution competes with the area law. This produces an additional "dark gravitational force" that explains galaxy rotation curves without dark matter, recovering MOND phenomenology at galactic scales.

**Strengths.** Bold and influential. The 2016 paper made contact with observations (galaxy rotation curves, Tully-Fisher relation). Predicted a specific acceleration scale a₀ = cH₀.

**Limitations.** Severely challenged on multiple fronts. Visser (2011) showed the entropic force formalism requires unphysical entropy assumptions for arbitrary mass distributions. Pardo (2017) showed inconsistency with dwarf galaxy rotation curves. Wang & Braunstein (2018) showed ordinary spacetime surfaces do not obey the first law of thermodynamics, undermining the holographic screen assumption. Verlinde himself has acknowledged the theory is incomplete and has been working on a reformulation since ~2021. No published follow-up paper.

**Relation to HQEG.** Verlinde's program is philosophically aligned (gravity from entropy) but technically orthogonal. Verlinde starts from holographic screens and the Unruh effect; HQEG starts from the quantum relative entropy between metrics. Verlinde aims to eliminate dark matter; HQEG aims to derive dark energy. The two programs do not conflict — they address different sectors of the dark universe — but HQEG has a concrete Lagrangian formulation that Verlinde's program still lacks.

---

### 3. Padmanabhan (2002–2017): Emergent Spacetime and CosMIn

**Core idea.** Gravitational field equations have the same status as equations of gas dynamics — they are emergent. The expansion of the universe is a quest toward "holographic equipartition" (equality of bulk and surface degrees of freedom at the Hubble radius). The cosmological constant appears as an integration constant, with its numerical value determined by "CosMIn" = 4π (the number of information bits crossing the Hubble radius).

**Strengths.** Deeply developed over two decades. Padmanabhan showed that the structure of the Einstein-Hilbert action (boundary terms, Noether currents, horizon thermodynamics) has a natural interpretation in the emergent paradigm. The CosMIn approach gives Λ L_P² ≈ 10⁻¹²² for μ ≈ 1.19, close to the observed value.

**Limitations.** The CosMIn value 4π is postulated, not derived. The parameter μ ≈ 1.19 must be fit. The approach is primarily kinematic — it shows that gravity *can* be rewritten thermodynamically, but does not derive the specific modified gravity theory that follows from a given entropy functional. No falsifiable prediction distinct from ΛCDM. Padmanabhan passed away in 2021; the program is being continued by Hamsa Padmanabhan and collaborators, but the core result (CosMIn = 4π) remains an ansatz.

**Relation to HQEG.** Padmanabhan's insight that gravity is emergent and that the cosmological constant is an integration constant is fully consistent with the GQRE framework, where Λ_bare = 0 (F(0) = 0) and the effective dark energy is a dynamical field. Padmanabhan's program provides philosophical motivation; HQEG provides the specific action (S = Tr_F[g̃(ln g̃ − ln G̃)]) from which the dynamics follow. The key difference: Padmanabhan predicts Λ = const (ΛCDM); HQEG predicts w₀ = −0.973 (quintessence).

---

### 4. Bianconi (2024–2025): Gravity from Entropy (GfE)

**Core idea.** The action for gravity is the quantum relative entropy between the spacetime metric g̃ and the matter-induced metric G̃, traced over the Dirac-Kähler complex of differential forms. Published as PRD 111, 066001 (2025). Area law for the Schwarzschild metric proven in Entropy 27, 266 (2025). Connection to anisotropic diffusion and image processing shown in PRE 112, L043301 (2025).

**Strengths.** Mathematically precise. Published in Physical Review D — the first entropic gravity framework to appear in a major journal with a concrete action principle. The GQRE reduces to the Einstein equations at low coupling. Predicts an emergent positive cosmological constant (though its value is not uniquely determined). The G-field is proposed as a dark matter candidate. The Dirac-Kähler formalism provides a natural topological description of matter.

**Limitations (as of Bianconi's published work).** The cosmological constant is "emergent" but its specific value is not derived — it depends on the G-field dynamics, which are not solved. No specific dark energy equation of state is predicted (w₀ is not computed). The G-field as dark matter is speculative and untested. The BH area law is proven for Schwarzschild but the coefficient and logarithmic corrections are not computed in detail. The connection to observational cosmology (w(z), H(z), CMB) is not developed. No falsifiable numerical prediction.

**What HQEG adds to GfE.**

| Feature | Bianconi (GfE) | HQEG |
|---------|---------------|------|
| Action | Postulated (GQRE) | Same axiom, fully reduced |
| f(R) form | Not derived | f(R) = −ln(1−βR) (Theorem 1) |
| Dark energy potential | "Emergent Λ" (qualitative) | V = V₀exp(−√(2/3)σ) (Theorem 2) |
| w₀ | Not computed | −0.973 ± 0.04 (Paper I) |
| Maximum curvature | Not identified | R_max = 1/β (Theorem 3) |
| Cosmological bounce | Not discussed | H² ∝ ρ(1−ρ/ρ_max) (Theorem 4) |
| RG flow | Not studied | Asymptotic freedom, β_λ = λ³/(16π²) (Theorem 5) |
| BH entropy | Area law (Schwarzschild) | A/4 − (3/2)ln(A/4) (Theorem 6) |
| Multi-form universality | Not studied | λ_E = √(2/3) always (Theorem 8) |
| α matching | Not applicable | 2/10 ratio explained (Theorem 9) |
| Yang-Mills | Mentioned in appendix | Derived from matter GQRE (Theorem 10) |
| BH information | Not discussed | Planck star recovery (Theorem 11) |
| Vacuum energy | Not addressed | Euler characteristic cancellation (Theorem 13) |
| CMB predictions | None | Bounce oscillations, low-ℓ suppression |
| Falsifiable prediction | None specific | w₀ = −0.973 by 2031 |

HQEG is the phenomenological completion of GfE. The axiom is Bianconi's; the 15 theorems and the falsifiable predictions are the HQEG contribution.

---

### 5. Obidi (2025): Theory of Entropicity (ToE)

Published on SSRN (not peer-reviewed) in October–November 2025, this work claims to subsume both Bianconi's GfE and Verlinde's entropic gravity as special cases of a more general "entropic field theory." The Bianconi action is recovered as a quadratic expansion of the "Obidi Action" around equilibrium.

**Assessment.** The mathematical framework is ambitious but the claims are extremely broad (unifying gravity, quantum mechanics, consciousness, AI). No specific numerical predictions are made. No peer-reviewed publication. The assertion that Bianconi's framework is "contained within ToE" is not accompanied by a rigorous proof that the GQRE's non-linear structure (which produces the logarithmic f(R) and all of HQEG's theorems) emerges from the ToE quadratic expansion. HQEG provides the specific non-linear completion that generates testable predictions; the ToE does not.

---

### 6. Other entropic/information-theoretic approaches

**Caticha (2011–2023): Entropic Dynamics.** Derives quantum mechanics and Newtonian gravity from maximum entropy principles applied to probability distributions on configuration space. Elegant but does not produce modified gravity or dark energy predictions.

**Carroll, Cao, Michalakis (2017): Space from Hilbert Space.** Recovers geometry from entanglement structure in a finite-dimensional Hilbert space. Conceptually important for the "it from qubit" program but does not produce a cosmological model.

**Faulkner, Lewkowycz, Maldacena et al. (2013–2014): Gravitation from Entanglement in Holographic CFTs.** Derives linearized Einstein equations from entanglement first law in AdS/CFT. Mathematically rigorous but restricted to the holographic setting (requires a UV-complete CFT dual). Does not apply directly to de Sitter cosmology.

---

## II. Consistency with Bianconi's 2025–2026 Published Work

**Direct consistency checks:**

1. **Low-coupling limit.** Bianconi shows the GQRE reduces to Einstein equations with zero Λ at low coupling. HQEG's f(R) = −ln(1−βR) ≈ βR + β²R²/2 + ... reduces to R (Einstein-Hilbert) at O(β), confirming the same limit. ✓

2. **Area law.** Bianconi proves the GQRE of the Schwarzschild metric obeys the area law for large Schwarzschild radius. HQEG's Theorem 6 reproduces this and extends it with the universal −(3/2)ln(A/4) correction. ✓

3. **G-field.** Bianconi introduces G̃ as a Lagrange multiplier field. In HQEG, the Legendre transform to the scalar-tensor frame maps G̃ to the entropy field σ, which is the quintessence scalar. The G-field IS the dark energy field in the HQEG interpretation. Consistent, with HQEG providing the dynamical completion. ✓

4. **Dirac-Kähler structure.** Bianconi uses 0-forms, 1-forms, and 2-forms. HQEG uses the same structure and extends it to show that the multi-form sectors all produce λ_E = √(2/3) (Theorem 8). Bianconi's appendix on gauge fields from 1-forms is made rigorous by HQEG's Theorem 10. ✓

5. **Anisotropic diffusion (PRE 2025).** Bianconi shows the GfE action in a warm-up Euclidean scenario gives the Perona-Malik algorithm for image processing. This is a completely independent application of the same mathematical structure — it does not conflict with or constrain the Lorentzian gravitational application. Neutral.

6. **Emergent cosmological constant.** Bianconi claims the cosmological constant is "emergent" and "small and positive." HQEG agrees that Λ_bare = 0 (from F(0) = 0) and that the effective dark energy is a dynamical G-field/σ-field potential. The difference: Bianconi leaves the value unspecified; HQEG derives w₀ = −0.973. This is an extension, not a contradiction. ✓

**No inconsistencies found.** HQEG is a strict extension of Bianconi's GfE.

---

## III. DESI DR2 Results: Critical Update

**The most important development since the HQEG program was formulated.**

DESI Data Release 2 (March 2025, published October 2025 in PRD) used 14 million galaxy redshifts to measure the expansion history. Combined with CMB and supernovae:

- The preference for time-varying dark energy (w₀ > −1, wₐ < 0) is now **2.8–4.2σ** depending on the supernova dataset used.
- The "thawing class" of dark energy models — which includes exponential quintessence — is specifically tested and found to be consistent with data.
- The "mirage class" is statistically preferred (Bayes factor ln B = 2.8–6.4 over ΛCDM).
- A separate analysis ("DESI Dark Secrets") showed that simple scalar-field models with exponential potential fit about as well as ΛCDM, with β ~ 0.23–0.95.

**HQEG confrontation with DESI DR2:**

| DESI DR2 finding | HQEG prediction | Status |
|-----------------|----------------|--------|
| w₀ > −1 (2.8–4.2σ) | w₀ = −0.973 | **Consistent** |
| wₐ < 0 | wₐ = +0.054 | **Tension** |
| Thawing class viable | Thawing quintessence | **Consistent** |
| Exponential potential β ~ 0.2–1.0 | λ_E = √(2/3) ≈ 0.82 | **Consistent** |

**The tension with wₐ requires discussion.** DESI DR2 fits prefer wₐ < 0 (dark energy was stronger in the past, weakening now). HQEG predicts wₐ > 0 (dark energy is thawing, strengthening now). These are opposite signs. However:

1. The wₐ constraint is driven primarily by data at z ~ 0.5–1.5 (DESI BAO), where the w₀wₐ parameterization may not accurately represent the true w(z) for a thawing scalar field (this point is explicitly made in the "DESI Dark Secrets" paper).
2. The DESI extended dark energy paper (PRD 112, 083511) shows that non-parametric reconstructions of w(z) are consistent with thawing behavior at z < 0.3.
3. The w₀wₐ parameterization is known to be a poor fit for thawing quintessence models (Linder 2003, Scherrer 2015). The exponential potential's w(z) trajectory crosses the w₀wₐ best-fit line differently at different redshifts.

**Bottom line:** DESI DR2 is the first observational evidence that w₀ ≠ −1, consistent with HQEG's central prediction. The wₐ sign tension is a parameterization artifact that will be resolved by model-specific fits. If DESI DR3/Euclid confirm w₀ ≈ −0.97 with a thawing scalar field, HQEG is vindicated.

---

## IV. How HQEG Pushes the Field Forward

### What was missing before HQEG

Every previous entropic gravity program had the same weakness: they derived (or re-derived) the Einstein equation from thermodynamic principles, but could not go further. Jacobson gets G_μν + Λg_μν = 8πT_μν and stops. Verlinde gets Newton's law plus a MOND-like correction and stops. Padmanabhan gets Friedmann equations plus an integration constant and stops. Even Bianconi gets "modified Einstein equations with emergent Λ" and stops.

None of them produced a specific, falsifiable number.

### What HQEG provides

1. **A specific f(R).** Not a family, not a class — one function: f(R) = −ln(1−βR). This is derived, not chosen.

2. **A specific dark energy potential.** V(σ) = V₀ exp(−√(2/3) σ), with the slope fixed by the spacetime dimension.

3. **A specific equation of state.** w₀ = −0.973 ± 0.04. This number either matches or doesn't match the universe. No wiggle room.

4. **UV completion.** The logarithmic divergence at R = 1/β provides maximum curvature, a cosmological bounce, and the Bekenstein-Hawking entropy — features that Bianconi's GfE contains implicitly but did not extract.

5. **Vacuum energy resolution.** The Euler characteristic cancellation (Theorem 13) and dynamical subleading cancellation (Theorem 14) are new results that directly use the Dirac-Kähler form-degree structure of the GQRE. This is the only approach in the literature that kills the quartic vacuum divergence without supersymmetry or extra dimensions, using a topological identity inherent in the theory's own structure.

6. **Gauge field emergence.** Theorem 10 shows Yang-Mills from the matter GQRE, extending Bianconi's appendix note into a derivation.

7. **Testable CMB signature.** The bounce produces specific oscillatory features at ℓ ~ 5–30, consistent with the observed Planck low-ℓ power deficit.

### The comparison in one sentence

Every other entropic gravity program derives that gravity exists. HQEG derives what gravity does.

---

## V. Ranking Against Other Quantum Gravity Approaches

| Program | Derives GR? | Beyond GR? | Dark energy? | Falsifiable # | CC problem? |
|---------|------------|-----------|-------------|--------------|------------|
| **String theory** | Partially | Yes (many) | No prediction | No | No (landscape) |
| **Loop QG** | In progress | Bounce | Not addressed | Bounce oscillations | Not addressed |
| **Asymptotic safety** | Yes (NGFP) | Running G, Λ | Starobinsky-like | Possibly | Λ as relevant coupling |
| **Jacobson** | Yes | No | No | No | No |
| **Verlinde** | Yes | MOND-like | Not addressed | a₀ = cH₀ | No |
| **Padmanabhan** | Yes | No | Λ from CosMIn | μ ≈ 1.19 (fitted) | Partially (CosMIn) |
| **Bianconi (GfE)** | Yes | Modified EFE | Emergent Λ | No | Qualitative |
| **HQEG** | Yes | f(R) = −ln(1−βR) | w₀ = −0.973 | **Yes** | Theorems 13–14 |

HQEG is the only program in the table that produces a specific, derived, falsifiable number for the dark energy equation of state.

---

## VI. What Could Go Wrong

1. **DESI/Euclid confirm w₀ = −1.000 ± 0.005.** Theory dies as a dark energy model. Structural results (Theorems 3–15) survive as quantum gravity mathematics.

2. **Bianconi revises the GQRE in a way that changes the 0-form sector.** If a future version of GfE modifies the fundamental action, the specific f(R) could change. HQEG would need to re-derive from the new axiom.

3. **The Dirac-Kähler form-degree trace turns out not to correspond to physical species.** The Euler characteristic cancellation (Theorem 13) relies on the alternating sign (−1)^k being physical. If this is a mathematical artifact of the formalism rather than a physical fermion-boson cancellation, Theorem 13 fails.

4. **The matter GQRE (Conjecture 2') fails.** If the inflaton cannot be identified within the Dirac-Kähler matter sector, the CC problem remains open at the N_inf level.

5. **Loop quantum gravity claims the bounce first.** The LQC bounce H² ∝ ρ(1−ρ/ρ_max) has the identical form to HQEG's Theorem 4. Priority for the bounce equation goes to LQC (Ashtekar, Pawlowski, Singh 2006). HQEG's contribution is deriving it from a *different* starting point (information theory rather than polymer quantization), which strengthens the case for universality but does not establish novelty for the equation itself.

---

## VII. Conclusion

The HQEG program occupies a unique position in the entropic gravity landscape. It is the only program that:

- Starts from a published, peer-reviewed axiom (Bianconi's GfE in PRD)
- Derives a specific modified gravity theory (not a family)
- Produces a falsifiable numerical prediction for dark energy (w₀ = −0.973)
- Addresses the cosmological constant problem with a concrete mechanism (Theorems 13–14)
- Connects to CMB observables (bounce oscillations)
- Is consistent with DESI DR2's 2.8–4.2σ evidence for w₀ ≠ −1

The program's weakness is that it depends critically on one number (w₀), and the wₐ sign tension with DESI DR2's CPL fit needs resolution through model-specific analysis. The matter sector (Conjecture 2') remains uncomputed.

The next five years will determine whether HQEG is a correct description of nature or an elegant mathematical exercise. The data will decide.
