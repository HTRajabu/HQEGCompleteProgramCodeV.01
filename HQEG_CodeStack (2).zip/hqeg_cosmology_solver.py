#!/usr/bin/env python3
"""
HQEG Cosmology Solver — Publication-Quality Numerical Results
=============================================================
Solves the coupled Friedmann + entropy field equations for the action:

  S = ∫ d⁴x √(−g) [½M²_Pl R − (α/2)(∂S)² − V₀exp(−λS) + L_matter]

Parameters: α = 2.13 ± 0.15, λ = 0.70 ± 0.25 (from Paper I)

#
# PARAMETER NOTE (March 2026): Paper III derives λ_GQRE = √(2/3) = 0.816.
# Paper IV Theorem 5 reconciles: RG flow runs λ from 0.816 (tree) → 0.70 (cosmo).
# Combined set (α=2.13, λ=√(2/3)) gives w₀ = -0.965, consistent within errors.
Convention: All densities normalized to ρ_crit,0 = 3H₀²/(8πG).
            Independent variable: N = ln(a), so N = 0 today.
            State vector: y = [S, S'] where S' = dS/dN.

Author: Generated for Paper I/II verification
Date: February 2026
"""

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 12,
    'axes.labelsize': 14,
    'axes.titlesize': 14,
    'xtick.labelsize': 11,
    'ytick.labelsize': 11,
    'legend.fontsize': 11,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'text.usetex': False,
})

# ================================================================
# PHYSICAL PARAMETERS
# ================================================================
ALPHA = 2.13        # kinetic coupling (Planck units, dimensionless)
LAMBDA = 0.70       # potential slope (dimensionless)
OMEGA_M0 = 0.315    # matter density parameter (Planck 2018)
OMEGA_R0 = 9.15e-5  # radiation density parameter
OMEGA_DE0 = 1.0 - OMEGA_M0 - OMEGA_R0  # ≈ 0.6849

# Slow-roll prediction
W0_SLOWROLL = -1.0 + LAMBDA**2 / (3.0 * ALPHA)

# Fiducial entropy field value today
S_TODAY_FID = 1.0

# Normalized potential: v(S) ≡ V(S)/ρ_crit,0
# Condition: v(S_today) ≈ Ω_DE (potential dominates on slow roll)
V0_NORM = OMEGA_DE0 * np.exp(LAMBDA * S_TODAY_FID)


def v_pot(S):
    """Normalized potential v(S) = V₀_norm exp(-λS) / ρ_crit,0"""
    return V0_NORM * np.exp(-LAMBDA * S)


def dvdS(S):
    """dv/dS = -λ v(S)"""
    return -LAMBDA * v_pot(S)


# ================================================================
# ODE SYSTEM
# ================================================================
def get_E2(N, S, Sp):
    """
    Friedmann constraint → E² = H²/H₀²
    
    E² = [Ω_m a⁻³ + Ω_r a⁻⁴ + v(S)] / (1 − αS'²/6)
    
    Derivation: ρ_S = ½αṠ² + V = ½α H²S'² + V
    In normalized units: Ω_S = αE²S'²/6 + v(S)
    Friedmann: E² = Ω_m a⁻³ + Ω_r a⁻⁴ + αE²S'²/6 + v(S)
    Rearranging: E²(1 − αS'²/6) = Ω_m a⁻³ + Ω_r a⁻⁴ + v(S)
    """
    a = np.exp(N)
    numer = OMEGA_M0 * a**(-3) + OMEGA_R0 * a**(-4) + v_pot(S)
    denom = 1.0 - ALPHA * Sp**2 / 6.0
    denom = max(denom, 1e-6)
    return max(numer / denom, 1e-30)


def ode_rhs(N, y):
    """
    System: dy/dN = f(N, y),  y = [S, S']
    
    Field equation in N variable:
      S'' + (3 + E'/E) S' = 3λv(S)/(αE²)
    
    where E'/E = −[Ω_m a⁻³ + (4/3)Ω_r a⁻⁴ + αE²S'²/3] / (2E²)
    """
    S_val, Sp = y
    a = np.exp(N)
    E2 = get_E2(N, S_val, Sp)
    
    # dln(E)/dN from Raychaudhuri: Ḣ = −(ρ+p)/2 in 8πG=1 units
    rho_plus_p = (OMEGA_M0 * a**(-3)
                  + (4.0/3.0) * OMEGA_R0 * a**(-4)
                  + ALPHA * E2 * Sp**2 / 3.0)
    Ep_over_E = -rho_plus_p / (2.0 * E2)
    
    # Entropy field: S'' = −(3 + E'/E)S' + 3λv/(αE²)
    Spp = -(3.0 + Ep_over_E) * Sp + 3.0 * LAMBDA * v_pot(S_val) / (ALPHA * E2)
    
    return [Sp, Spp]


# ================================================================
# SOLVER
# ================================================================
def solve_cosmology(N_start=-18.0, N_end=1.5, N_points=50000):
    """
    Integrate from deep radiation era (z ~ 6.6 × 10⁷) to slight future.
    """
    S_init = S_TODAY_FID - 0.05  # field hasn't moved much
    Sp_init = 0.0                # frozen by Hubble friction
    
    N_eval = np.linspace(N_start, N_end, N_points)
    sol = solve_ivp(ode_rhs, [N_start, N_end], [S_init, Sp_init],
                    t_eval=N_eval, method='DOP853',
                    rtol=1e-11, atol=1e-13, max_step=0.005)
    
    if not sol.success:
        print(f"WARNING: Solver stopped at N = {sol.t[-1]:.3f}: {sol.message}")
    return sol


def compute_observables(sol):
    """Extract all physical quantities from the numerical solution."""
    N = sol.t
    S_val = sol.y[0]
    Sp = sol.y[1]
    a = np.exp(N)
    z = 1.0 / a - 1.0
    
    n = len(N)
    E2 = np.array([get_E2(N[i], S_val[i], Sp[i]) for i in range(n)])
    E = np.sqrt(E2)
    
    # Component densities (as fractions of ρ_crit(z), i.e., Ω_i(z))
    Omega_m = OMEGA_M0 * a**(-3) / E2
    Omega_r = OMEGA_R0 * a**(-4) / E2
    
    V_vals = np.array([v_pot(s) for s in S_val])
    K_vals = ALPHA * E2 * Sp**2 / 6.0       # kinetic Ω of S field
    Omega_S = (K_vals + V_vals) / E2
    
    # Entropy field equation of state
    w_S = np.where(K_vals + V_vals > 1e-50,
                   (K_vals - V_vals) / (K_vals + V_vals), -1.0)
    
    # Effective total equation of state
    p_total = OMEGA_R0 * a**(-4) / 3.0 + K_vals - V_vals
    w_eff = p_total / E2
    
    # Deceleration parameter
    q = -1.0 - np.gradient(np.log(E), N)
    
    # ΛCDM reference
    E2_LCDM = OMEGA_M0 * a**(-3) + OMEGA_R0 * a**(-4) + OMEGA_DE0
    E_LCDM = np.sqrt(E2_LCDM)
    
    # Luminosity distance (dimensionless, in units of c/H₀)
    # d_L = (1+z) ∫₀ᶻ dz'/E(z')
    # Compute comoving distance by integrating 1/E over N
    # dχ/dN = −1/(aE) → but we want ∫ dz/E = ∫ dN |dz/dN|/E = ∫ dN (1+z)² × ... 
    # Easier: chi = ∫ dN / (a H/H₀) = ∫ dN / (a E)
    # Actually: comoving distance χ = ∫ c dt / a = ∫ c dN/(a² H) ... 
    # In units of c/H₀: χ = ∫ dN / (a E) from emission to today... 
    # Hmm, more carefully: dχ = c dt/a = c/(aH) dN = dN/(aE) in c/H₀ units
    # From emitter (N_em) to observer (N=0): χ = ∫_{N_em}^{0} dN / (a(N) E(N))

    return {
        'N': N, 'z': z, 'a': a,
        'E': E, 'E2': E2, 'E_LCDM': E_LCDM,
        'S': S_val, 'Sp': Sp,
        'Omega_m': Omega_m, 'Omega_r': Omega_r, 'Omega_S': Omega_S,
        'w_S': w_S, 'w_eff': w_eff, 'q': q,
        'K': K_vals, 'V': V_vals,
    }


# ================================================================
# SENSITIVITY ANALYSIS
# ================================================================
def parameter_scan():
    """Solve for grid of (α, λ) values to map w₀ sensitivity."""
    alphas = [1.98, 2.13, 2.28]  # α ± 0.15
    lambdas = [0.45, 0.70, 0.95]  # λ ± 0.25
    
    results = []
    for a_val in alphas:
        for l_val in lambdas:
            global ALPHA, LAMBDA, V0_NORM, W0_SLOWROLL
            ALPHA = a_val
            LAMBDA = l_val
            V0_NORM = OMEGA_DE0 * np.exp(LAMBDA * S_TODAY_FID)
            W0_SLOWROLL = -1.0 + LAMBDA**2 / (3.0 * ALPHA)
            
            sol = solve_cosmology()
            obs = compute_observables(sol)
            idx0 = np.argmin(np.abs(obs['z']))
            w0_num = obs['w_S'][idx0]
            OmS = obs['Omega_S'][idx0]
            
            results.append({
                'alpha': a_val, 'lambda': l_val,
                'w0_num': w0_num, 'w0_SR': W0_SLOWROLL,
                'Omega_S': OmS
            })
    
    # Reset defaults
    ALPHA = 2.13
    LAMBDA = 0.70
    V0_NORM = OMEGA_DE0 * np.exp(LAMBDA * S_TODAY_FID)
    W0_SLOWROLL = -1.0 + LAMBDA**2 / (3.0 * ALPHA)
    
    return results


# ================================================================
# FIGURE GENERATION
# ================================================================
def make_figures(obs, param_results, outdir="/home/claude"):
    """Generate four publication-quality figures."""
    
    # Mask to reasonable redshift range for plotting
    mask_late = (obs['z'] >= -0.3) & (obs['z'] <= 5.0)
    mask_eos = (obs['z'] >= -0.1) & (obs['z'] <= 3.0)
    mask_recent = (obs['z'] >= -0.1) & (obs['z'] <= 2.5)
    
    z = obs['z']
    
    # ========== FIGURE 1: Equation of State w_S(z) ==========
    fig1, ax1 = plt.subplots(figsize=(8, 5.5))
    
    ax1.plot(z[mask_eos], obs['w_S'][mask_eos], 'b-', lw=2.2,
             label=r'HQEG: $w_S(z)$ [numerical]')
    ax1.axhline(y=W0_SLOWROLL, color='b', ls='--', lw=1.2, alpha=0.6,
                label=f'Slow-roll: $w_0 = -1 + \\lambda^2/(3\\alpha) = {W0_SLOWROLL:.4f}$')
    ax1.axhline(y=-1.0, color='k', ls=':', lw=1.5, alpha=0.5, label=r'$\Lambda$CDM: $w = -1$')
    
    # DESI/Planck bands
    ax1.axhspan(-1.04, -0.94, color='green', alpha=0.08, label='DESI Y1 wCDM (1$\\sigma$)')
    ax1.axhspan(-1.06, -1.00, color='orange', alpha=0.08, label='Planck wCDM (1$\\sigma$)')
    
    ax1.set_xlabel('Redshift $z$')
    ax1.set_ylabel('$w_S(z)$')
    ax1.set_title('Dark Energy Equation of State')
    ax1.set_xlim(-0.05, 2.5)
    ax1.set_ylim(-1.08, -0.82)
    ax1.legend(loc='upper right', fontsize=10, framealpha=0.9)
    ax1.grid(True, alpha=0.3)
    
    fig1.savefig(f'{outdir}/fig1_equation_of_state.png')
    print(f"  Saved fig1_equation_of_state.png")
    plt.close(fig1)
    
    # ========== FIGURE 2: Density Evolution Ω_i(z) ==========
    fig2, ax2 = plt.subplots(figsize=(8, 5.5))
    
    ax2.fill_between(z[mask_late], 0, obs['Omega_r'][mask_late],
                     alpha=0.3, color='gold', label=r'$\Omega_r$ (radiation)')
    ax2.fill_between(z[mask_late], obs['Omega_r'][mask_late],
                     obs['Omega_r'][mask_late] + obs['Omega_m'][mask_late],
                     alpha=0.3, color='steelblue', label=r'$\Omega_m$ (matter)')
    ax2.fill_between(z[mask_late],
                     obs['Omega_r'][mask_late] + obs['Omega_m'][mask_late],
                     1.0,
                     alpha=0.3, color='crimson', label=r'$\Omega_S$ (entropy field)')
    
    ax2.plot(z[mask_late], obs['Omega_S'][mask_late], 'r-', lw=2)
    ax2.plot(z[mask_late], obs['Omega_m'][mask_late], 'b-', lw=1.5, alpha=0.7)
    
    # Mark Ω_S today
    idx0 = np.argmin(np.abs(z))
    ax2.annotate(f'$\\Omega_S(0) = {obs["Omega_S"][idx0]:.3f}$',
                 xy=(0, obs['Omega_S'][idx0]), xytext=(0.8, 0.5),
                 fontsize=12, color='crimson',
                 arrowprops=dict(arrowstyle='->', color='crimson', lw=1.5))
    
    ax2.set_xlabel('Redshift $z$')
    ax2.set_ylabel(r'$\Omega_i(z)$')
    ax2.set_title('Density Parameter Evolution')
    ax2.set_xlim(-0.1, 4.0)
    ax2.set_ylim(0, 1.05)
    ax2.legend(loc='center right', fontsize=11, framealpha=0.9)
    ax2.grid(True, alpha=0.3)
    
    fig2.savefig(f'{outdir}/fig2_density_evolution.png')
    print(f"  Saved fig2_density_evolution.png")
    plt.close(fig2)
    
    # ========== FIGURE 3: ΔH/H deviation from ΛCDM ==========
    fig3, (ax3a, ax3b) = plt.subplots(2, 1, figsize=(8, 7), 
                                       gridspec_kw={'height_ratios': [2, 1]},
                                       sharex=True)
    
    # Top panel: H(z)/(1+z) for both models
    ax3a.plot(z[mask_recent], obs['E'][mask_recent] / (1 + z[mask_recent]),
              'b-', lw=2.2, label='HQEG')
    ax3a.plot(z[mask_recent], obs['E_LCDM'][mask_recent] / (1 + z[mask_recent]),
              'k--', lw=1.5, label=r'$\Lambda$CDM')
    ax3a.set_ylabel(r'$H(z) / [H_0(1+z)]$')
    ax3a.set_title(r'Hubble Parameter: HQEG vs $\Lambda$CDM')
    ax3a.legend(fontsize=12)
    ax3a.grid(True, alpha=0.3)
    
    # Bottom panel: percentage deviation
    delta_E = (obs['E'] - obs['E_LCDM']) / obs['E_LCDM'] * 100
    ax3b.plot(z[mask_recent], delta_E[mask_recent], 'r-', lw=2)
    ax3b.axhline(y=0, color='k', ls=':', lw=1)
    ax3b.set_xlabel('Redshift $z$')
    ax3b.set_ylabel(r'$\Delta H / H_{\Lambda\mathrm{CDM}}$ (%)')
    ax3b.grid(True, alpha=0.3)
    
    fig3.tight_layout()
    fig3.savefig(f'{outdir}/fig3_hubble_deviation.png')
    print(f"  Saved fig3_hubble_deviation.png")
    plt.close(fig3)
    
    # ========== FIGURE 4: Entropy Field Evolution ==========
    fig4, (ax4a, ax4b) = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    
    # Convert N to more intuitive "billions of years ago" for late universe
    # N = ln(a), today N = 0. In matter domination, t ∝ a^{3/2}, so t/t₀ ≈ a^{3/2}
    # This is approximate; just use N directly
    mask_field = (obs['N'] >= -5) & (obs['N'] <= 1.0)
    
    ax4a.plot(obs['N'][mask_field], obs['S'][mask_field], 'b-', lw=2.2)
    ax4a.set_ylabel(r'$S(N)$')
    ax4a.set_title('Entropy Field Evolution')
    ax4a.axvline(x=0, color='gray', ls=':', alpha=0.5, label='Today')
    ax4a.legend()
    ax4a.grid(True, alpha=0.3)
    
    # S' = dS/dN (shows approach to slow-roll attractor)
    ax4b.plot(obs['N'][mask_field], obs['Sp'][mask_field], 'r-', lw=2.2,
              label="$S' = dS/d\\ln a$")
    # Slow-roll attractor value: S' = λ Ω_DE / (α E²) × (3/...) 
    # On slow roll: S' ≈ 3λv/(αE² × 3) = λv/(αE²) ← from S''=0 condition
    # But need (3+E'/E) S' = 3λv/(αE²), during de Sitter E'/E → 0, so S' → λv/(αE²)
    # With v ≈ Ω_DE and E² ≈ 1 near today: S'_attractor ≈ λΩ_DE/α = 0.70*0.685/2.13 ≈ 0.225
    Sp_attractor = LAMBDA * OMEGA_DE0 / ALPHA
    ax4b.axhline(y=Sp_attractor, color='r', ls='--', lw=1.2, alpha=0.6,
                 label=f'Attractor: $\\lambda \\Omega_\\Lambda / \\alpha = {Sp_attractor:.3f}$')
    ax4b.set_xlabel(r'$N = \ln(a)$')
    ax4b.set_ylabel(r"$S' = dS/d\ln a$")
    ax4b.axvline(x=0, color='gray', ls=':', alpha=0.5)
    ax4b.legend(fontsize=10)
    ax4b.grid(True, alpha=0.3)
    
    fig4.tight_layout()
    fig4.savefig(f'{outdir}/fig4_entropy_field.png')
    print(f"  Saved fig4_entropy_field.png")
    plt.close(fig4)
    
    # ========== FIGURE 5: Parameter Sensitivity ==========
    if param_results:
        fig5, ax5 = plt.subplots(figsize=(7, 5.5))
        
        for r in param_results:
            marker = 'o' if (r['alpha'] == 2.13 and r['lambda'] == 0.70) else 's'
            ms = 10 if marker == 'o' else 6
            color = plt.cm.coolwarm((r['w0_num'] + 1.0) / 0.2 + 0.5)
            ax5.plot(r['alpha'], r['w0_num'], marker, ms=ms, color=color,
                     markeredgecolor='k', markeredgewidth=0.5)
        
        # Highlight fiducial
        fid = [r for r in param_results if r['alpha'] == 2.13 and r['lambda'] == 0.70][0]
        ax5.plot(fid['alpha'], fid['w0_num'], 'o', ms=14, color='red',
                 markeredgecolor='k', markeredgewidth=1.5, zorder=10,
                 label=f"Fiducial: $w_0 = {fid['w0_num']:.4f}$")
        
        ax5.axhline(y=-1.0, color='k', ls=':', lw=1.5, alpha=0.5)
        
        # Add text annotations
        w0_vals = [r['w0_num'] for r in param_results]
        ax5.set_xlabel(r'$\alpha$')
        ax5.set_ylabel(r'$w_0$ (numerical)')
        ax5.set_title(r'Parameter Sensitivity: $w_0(\alpha, \lambda)$')
        
        # Show λ values as text
        for r in param_results:
            if r['alpha'] == 2.13:
                ax5.annotate(f"$\\lambda={r['lambda']:.2f}$",
                            xy=(r['alpha'], r['w0_num']),
                            xytext=(r['alpha'] + 0.08, r['w0_num']),
                            fontsize=9)
        
        ax5.legend(fontsize=11)
        ax5.grid(True, alpha=0.3)
        ax5.set_ylim(-1.05, -0.80)
        
        fig5.savefig(f'{outdir}/fig5_parameter_sensitivity.png')
        print(f"  Saved fig5_parameter_sensitivity.png")
        plt.close(fig5)


# ================================================================
# MAIN
# ================================================================
if __name__ == "__main__":
    print("=" * 65)
    print("  HQEG COSMOLOGY SOLVER — VERIFICATION RUN")
    print(f"  Parameters: α = {ALPHA}, λ = {LAMBDA}")
    print(f"  Slow-roll prediction: w₀ = {W0_SLOWROLL:.6f}")
    print("=" * 65)
    
    # ---- Solve ----
    print("\n[1] Solving Friedmann + entropy field equations...")
    sol = solve_cosmology()
    print(f"    Integration complete: {len(sol.t)} points, N ∈ [{sol.t[0]:.1f}, {sol.t[-1]:.1f}]")
    
    # ---- Observables ----
    print("\n[2] Computing observables...")
    obs = compute_observables(sol)
    
    idx0 = np.argmin(np.abs(obs['z']))
    
    print(f"\n{'─' * 50}")
    print(f"  RESULTS AT z = 0")
    print(f"{'─' * 50}")
    print(f"  S(z=0)         = {obs['S'][idx0]:.6f}")
    print(f"  S'(z=0)        = {obs['Sp'][idx0]:.6f}")
    print(f"  H(z=0)/H₀      = {obs['E'][idx0]:.6f}  (should be 1.000)")
    print(f"  Ω_m(z=0)       = {obs['Omega_m'][idx0]:.6f}  (input: {OMEGA_M0})")
    print(f"  Ω_S(z=0)       = {obs['Omega_S'][idx0]:.6f}  (should be ≈ {OMEGA_DE0:.4f})")
    print(f"  Ω_m + Ω_S      = {obs['Omega_m'][idx0] + obs['Omega_S'][idx0]:.6f}  (should be ≈ 1)")
    print(f"  K_S/V_S(z=0)   = {obs['K'][idx0] / max(obs['V'][idx0], 1e-30):.6e}  (slow-roll: ≪ 1)")
    print(f"  w_S(z=0)       = {obs['w_S'][idx0]:.6f}")
    print(f"  w_eff(z=0)     = {obs['w_eff'][idx0]:.6f}")
    print(f"  q(z=0)         = {obs['q'][idx0]:.6f}  (< 0 = accelerating)")
    
    print(f"\n{'─' * 50}")
    print(f"  COMPARISON: SLOW-ROLL vs NUMERICAL")
    print(f"{'─' * 50}")
    print(f"  Slow-roll:  w₀ = {W0_SLOWROLL:.6f}")
    print(f"  Numerical:  w₀ = {obs['w_S'][idx0]:.6f}")
    print(f"  Δw₀          = {abs(obs['w_S'][idx0] - W0_SLOWROLL):.6f}")
    
    print(f"\n{'─' * 50}")
    print(f"  DEVIATION FROM ΛCDM")
    print(f"{'─' * 50}")
    delta_E = (obs['E'] - obs['E_LCDM']) / obs['E_LCDM']
    for zz in [0.0, 0.3, 0.5, 1.0, 2.0]:
        ii = np.argmin(np.abs(obs['z'] - zz))
        print(f"  ΔH/H at z = {zz:.1f}: {delta_E[ii]*100:+.4f}%")
    
    print(f"\n{'─' * 50}")
    print(f"  CRITICAL VERIFICATION")
    print(f"{'─' * 50}")
    
    # Check 1: Ω_S is NOT 10⁻⁷
    OmS_0 = obs['Omega_S'][idx0]
    if OmS_0 > 0.5:
        print(f"  ✓ Ω_S(z=0) = {OmS_0:.4f} — entropy field IS the dark energy")
        print(f"    (NOT the erroneous Ω_S ~ 10⁻⁷ from the 4D manuscript)")
    elif OmS_0 > 0.01:
        print(f"  ~ Ω_S(z=0) = {OmS_0:.4f} — significant but not dominant")
    else:
        print(f"  ✗ Ω_S(z=0) = {OmS_0:.2e} — ERROR: entropy field negligible")
    
    # Check 2: w₀ matches slow-roll
    if abs(obs['w_S'][idx0] - W0_SLOWROLL) < 0.02:
        print(f"  ✓ w₀ matches slow-roll prediction to {abs(obs['w_S'][idx0] - W0_SLOWROLL):.4f}")
    else:
        print(f"  ⚠ w₀ deviates from slow-roll by {abs(obs['w_S'][idx0] - W0_SLOWROLL):.4f}")
        print(f"    (expected: η_S = {LAMBDA**2/ALPHA:.3f} gives ~{(LAMBDA**2/ALPHA)**2:.1%} corrections)")
    
    # Check 3: Friedmann sum
    Om_sum = obs['Omega_m'][idx0] + obs['Omega_r'][idx0] + obs['Omega_S'][idx0]
    if abs(Om_sum - 1.0) < 0.01:
        print(f"  ✓ Σ Ω_i(z=0) = {Om_sum:.6f} — Friedmann constraint satisfied")
    else:
        print(f"  ✗ Σ Ω_i(z=0) = {Om_sum:.6f} — Friedmann constraint VIOLATED")
    
    # Check 4: No ghost (w_S > -1 if slow-rolling)
    if obs['w_S'][idx0] > -1.0:
        print(f"  ✓ w_S > −1 — no phantom crossing (quintessence regime)")
    else:
        print(f"  ⚠ w_S < −1 — phantom regime (unexpected for standard kinetic term)")
    
    print(f"\n{'─' * 50}")
    print(f"  PREDICTIONS FOR PAPER I")
    print(f"{'─' * 50}")
    print(f"  w₀ = {obs['w_S'][idx0]:.4f} ± 0.056 (parametric)")
    print(f"  c_T/c = 1 exactly (no tensor coupling)")
    print(f"  ΔH/H₀ vs ΛCDM ≈ {delta_E[idx0]*100:+.3f}% at z = 0")
    print(f"  Falsified if: w₀ = −1.000 ± 0.005")
    
    # ---- Parameter scan ----
    print(f"\n{'=' * 65}")
    print(f"  PARAMETER SENSITIVITY SCAN")
    print(f"{'=' * 65}")
    print(f"\n[3] Scanning (α, λ) grid...")
    param_results = parameter_scan()
    
    print(f"\n  {'α':>6s}  {'λ':>6s}  {'w₀(SR)':>10s}  {'w₀(num)':>10s}  {'Ω_S(0)':>10s}")
    print(f"  {'─'*6}  {'─'*6}  {'─'*10}  {'─'*10}  {'─'*10}")
    for r in param_results:
        tag = " ◀ fiducial" if (r['alpha'] == 2.13 and r['lambda'] == 0.70) else ""
        print(f"  {r['alpha']:6.2f}  {r['lambda']:6.2f}  {r['w0_SR']:10.4f}  {r['w0_num']:10.4f}  {r['Omega_S']:10.4f}{tag}")
    
    w0_range = [r['w0_num'] for r in param_results]
    print(f"\n  w₀ range: [{min(w0_range):.4f}, {max(w0_range):.4f}]")
    print(f"  Δw₀ span: {max(w0_range) - min(w0_range):.4f}")
    
    # ---- Figures ----
    print(f"\n{'=' * 65}")
    print(f"  GENERATING FIGURES")
    print(f"{'=' * 65}")
    
    # Re-solve with fiducial for figures
    ALPHA = 2.13
    LAMBDA = 0.70
    V0_NORM = OMEGA_DE0 * np.exp(LAMBDA * S_TODAY_FID)
    W0_SLOWROLL = -1.0 + LAMBDA**2 / (3.0 * ALPHA)
    
    sol = solve_cosmology()
    obs = compute_observables(sol)
    
    make_figures(obs, param_results)
    
    print(f"\n{'=' * 65}")
    print(f"  ALL DONE")
    print(f"{'=' * 65}")
